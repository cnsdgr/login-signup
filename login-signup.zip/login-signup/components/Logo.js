import React from 'react';
import {Image,StyleSheet} from 'react-native';

import logo from '../assets/slider-100kadinyazilimci-1030x392.png';

const Logo=(props)=>{
  const birlesikStyle=StyleSheet.flatten([styles.logo,props.style]);

  return(

    <Image
    style={birlesikStyle}
    source={logo}
    />
  );
}


const styles=StyleSheet.create({

  logo:{
    width:350,
    height:150,
    alignSelf:'center',
    marginBottom:100,
  }

})

export default Logo;